KisanShield Sentinel — Pro Design v2

FILES
- index.html: redesigned responsive website with CSS and JavaScript included.
- README.txt: setup instructions.

OPEN ON ANDROID USING SPCK EDITOR
1. Download and extract KisanShield_Sentinel_Pro.zip.
2. Open the extracted folder in SPCK Editor, or copy index.html into your existing project.
3. If you already have an index.html, save a backup before replacing it.
4. Open index.html and tap Preview/Run.
5. Test the demo by changing moisture and temperature, then tapping Analyse sample.

NOTE
This is a visual prototype with illustrative values and simple demo rules. It does not read real sensors, save historical records, or diagnose crop disease. Real sensor calibration and field validation are needed before agricultural use.
